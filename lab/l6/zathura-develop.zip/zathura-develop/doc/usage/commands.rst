Commands
========

By pressing colon one can execute different commands in zathura:

.. include:: ../man/_commands.txt
