/* SPDX-License-Identifier: Zlib */

#ifndef ZATHURA_TESTS_H
#define ZATHURA_TESTS_H

#include <check.h>

int run_suite(Suite* suite);
void setup(void);

#endif
