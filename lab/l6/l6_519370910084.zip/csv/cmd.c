//
// Created by lanwang on 10/27/21.
//

#include "interface.h"

int main(int argc, char **argv) {
    dispatchCmd(argc,argv);
    return 0;
}
