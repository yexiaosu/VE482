//
// Created by lanwang on 10/27/21.
//

#ifndef HW3_LOGIC_H
#define HW3_LOGIC_H

#include "list.h"

int run(char* fileName,int dataType,int sortType);

void printList(const list *src, int dataType);

//char *getOutFileName(int dataType, int sortType);

#endif //HW3_LOGIC_H
