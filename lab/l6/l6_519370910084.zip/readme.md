# ReadMe

## Files

Source files for part 3 are in `csv` directory, and have been uploaded to JOJ.

`rand_char.txt` is a sample testcase. To use it, change the filename to `rand_char*.txt`.

## How to use

Build:

```
make
```

Run:

```
./l6 rand_char*.txt inc
```

