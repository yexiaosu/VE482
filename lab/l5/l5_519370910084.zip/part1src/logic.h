//
// Created by lanwang on 10/27/21.
//

#ifndef HW3_LOGIC_H
#define HW3_LOGIC_H

#include "list.h"

int getDataType(char *fileName);

int getSortType(char *arg);

char *getOutFileName(int dataType, int sortType);

#endif //HW3_LOGIC_H
