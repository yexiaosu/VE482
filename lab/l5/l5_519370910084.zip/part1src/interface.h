//
// Created by lanwang on 10/27/21.
//

#ifndef HW3_INTERFACE_H
#define HW3_INTERFACE_H

#include "logic.h"

int dispatchMenu();

int dispatchCmd(int argc, char *argv[]);

#endif //HW3_INTERFACE_H
