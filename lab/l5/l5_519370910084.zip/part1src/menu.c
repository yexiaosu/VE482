//
// Created by lanwang on 10/27/21.
//

#include "interface.h"

int main() {
    dispatchMenu();
    return 0;
}
